
import os
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

st.set_page_config(
    page_title="Retail Price Intelligence",
    page_icon="🛍️",
    layout="wide"
)

BASE = os.path.dirname(os.path.abspath(__file__))

st.title("Global Retail Price Intelligence")
st.write("Retail Data Analytics & Machine Learning Dashboard")

df = pd.read_csv(os.path.join(BASE, "retail_cleaned.csv"))

# KPIs
c1, c2, c3 = st.columns(3)
c1.metric("Total Records", f"{len(df):,}")
c2.metric("Product Categories", df["category"].nunique())
c3.metric("Currencies", df["currency"].nunique())

st.header("1. Data Quality")
st.write("Missing values by column")
st.dataframe(df.isna().sum().rename("Missing Values"))

st.header("2. Exploratory Data Analysis")
sns.set_theme(style="whitegrid")

fig, ax = plt.subplots()
sns.histplot(data=df, x="price", bins=30, ax=ax)
ax.set_title("Retail Price Distribution (Mixed Currencies)")
st.pyplot(fig)
plt.close(fig)

fig, ax = plt.subplots()
df["currency"].value_counts().plot(kind="bar", ax=ax)
ax.set_title("Records by Currency")
ax.set_ylabel("Record Count")
st.pyplot(fig)
plt.close(fig)

fig, ax = plt.subplots()
df["category"].fillna("Missing").value_counts().head(10).plot(
    kind="bar", ax=ax
)
ax.set_title("Top Product Categories")
st.pyplot(fig)
plt.close(fig)

fig, ax = plt.subplots()
df["store_name"].fillna("Missing").value_counts().head(10).plot(
    kind="bar", ax=ax
)
ax.set_title("Top Stores by Record Count")
st.pyplot(fig)
plt.close(fig)

df["date_recorded"] = pd.to_datetime(
    df["date_recorded"], errors="coerce"
)
eur = df[
    (df["currency"] == "EUR") &
    df["date_recorded"].notna() &
    df["price"].notna()
]

if not eur.empty:
    monthly = (
        eur.set_index("date_recorded")["price"]
        .resample("ME").median().dropna()
    )
    if not monthly.empty:
        st.subheader("Monthly Median Price (EUR)")
        st.line_chart(monthly)

st.header("3. Model Evaluation")
model_path = os.path.join(BASE, "retail_price_model.joblib")

if os.path.exists(model_path):
    st.info(
        "Saved EUR price model. Previously measured test results "
        "are shown below; this dashboard does not retrain the model."
    )
    m1, m2, m3 = st.columns(3)
    m1.metric("Test MAE", "1.519")
    m2.metric("Test RMSE", "2.394")
    m3.metric("Test R²", "0.052")

    st.warning(
        "The model only slightly outperformed the median baseline. "
        "Its predictive performance is weak and requires improvement."
    )

st.header("4. Business Recommendations")
st.markdown("""
- Compare prices only within the same currency.
- Investigate missing product and brand information.
- Validate price records before using them for business decisions.
- Improve predictive features and test model performance on future data.
- Do not use this weak model for automated pricing decisions.
""")

st.header("5. Limitations")
st.write(
    "This dashboard is an analytical prototype. "
    "Price associations do not establish causation. "
    "Model predictions are experimental and require further validation."
)
