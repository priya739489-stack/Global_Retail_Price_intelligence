# Global Retail Price Intelligence

## 1. Project Overview
This project analyzes global retail product price records and
demonstrates a data analytics and machine learning workflow.

## 2. Problem Statement
Retail prices may vary across products, categories, stores,
locations, currencies, and dates. Data analytics can help
identify patterns and support better pricing decisions.

## 3. Dataset
- Source file: global_retail_prices_dataset.csv
- Cleaned file: retail_cleaned.csv
- Records: 2,000
- Columns in cleaned dataset: 10

## 4. Data Quality Findings
- Duplicate rows in the checked cleaned dataset: 0
- Missing product_code values: 134
- Missing product_name values: 461
- Missing category values: 1,866
- Missing price values: 0

The large number of missing category and product-name values
limits category-level and product-level conclusions.
Missing values should not be replaced with invented labels
or unsupported assumptions.

## 5. Price Summary
- Mean price: approximately 34.24
- Median price: approximately 4.37
- Minimum price: 0.23
- Maximum price: 5,030.00

The large difference between the mean and median suggests
a right-skewed price distribution or potentially extreme
observations. Prices should be reviewed in their currency
context before comparing products.

## 6. Exploratory Data Analysis
The project dashboard presents exploratory analysis.
Interpret each chart using the observed dataset and avoid
claiming causation from descriptive patterns.

## 7. Machine Learning
The current model estimates price using available features.
The recorded evaluation results were:
- MAE: 1.519
- RMSE: 2.394
- R-squared: 0.052
- Baseline MAE: 1.550

The low R-squared indicates that the model explains little
of the variation in test-set prices. Its MAE is only slightly
better than the baseline. It is not ready for operational
pricing decisions.

## 8. Business Recommendations
1. Improve the completeness of category and product-name data.
2. Verify currencies and normalize prices before cross-country
   price comparisons.
3. Investigate extreme prices using product and currency context.
4. Compare future models with a simple baseline on held-out data.
5. Monitor errors and validate predictions before business use.

## 9. Limitations
Results are limited by missing product information, possible
currency differences, extreme prices, and weak predictive
performance. Correlation and predictive performance do not
establish causation.

## 10. How to Run the Dashboard
Install dependencies from requirements.txt and run:
streamlit run app.py

## 11. Conclusion
The project provides a retail price analytics dashboard and
an initial machine learning baseline. Data completeness and
model performance should be improved before using predictions
for real pricing decisions.
